<section id="pav-slideshow" class="pav-slideshow hidden-xs">
    <div class="container">
        <div class="row">   
            <!-- Checkout -->
            <div class="col-lg-12 col-md-12">
                <div class="layerslider-wrapper hidden-xs">
                    <div class="bannercontainer banner-boxed" style="padding: 5px 0px;margin: 0px 0px;">
                        <div id="content" class="product-detail">
                            <div class="product-info">
                                <div class="row">
                                    <div class="col-md-12">
										<div class="panel panel-primary" >
                                            <div class="panel-heading"><i class="fa fa-unlock-alt" aria-hidden="true"></i>
                                                Order Done
                                            </div>

                                            <div class="panel-body">
                                                <div class="col-md-12">
                                                    <h2>Your order has been placed Successfully ! We'll Contact with you very soon.</h2>
                                                </div>
                                            </div>
                                        </div><!-- panel-default -->
                                    </div><!-- col-md-8 -->
                                </div><!-- row -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Checkout end -->        
        </div>  
    </div>
</section>