<div class="container">
	<div class="row">
		<div class="col-md-12">
			<div class="topnavarea">
				<a href="<?= base_url('welcome/');?>" title="HomePage">Home</a> /&nbsp;How to order gift
			</div>
		</div>
	</div>
</div>

<div class="container">
	<div class="row">
		<div class="col-md-12">
			<div class="leftmenuarea menudisplay">
				<div class="leftmenu">
					<?php include('leftmenu.php');?>
				</div>
			</div>
			<div class="rightcontentarea">
				<div class="headarea">
					<div class="headtext">How to Order</div>
				</div>
				
				<h3>Step by step instruction to place gift orders for Bangladesh online:&nbsp;<span style="color: rgb(255, 0, 0);"><strong><br /><br/></strong></span></h3><span style="color: rgb(255, 0, 0);"><strong>Step1:</strong></span><strong>&nbsp;</strong> Please visit our website (আমাদের ওয়েবসাইটে যান): http://www.upoharbangla.com<br /><br/><img src="<?= base_url('assets/front/');?>images/uploads/Banners/1.jpg" alt="1" align="absMiddle" height="352" border="1" width="800" /><br /><br/><span style="color: rgb(255, 0, 0);"><strong>Step 2:</strong></span><strong> </strong>Visit gift categories and choose gift items (আমাদের উপহার catagory গুলো থেকে আপনার পছন্দ মতো উপহার আইটেমটি নির্বাচন করুন)<br /><br/><img src="<?= base_url('assets/front/');?>images/uploads/Banners/2.jpg" alt="2" align="absMiddle" height="428" border="1" width="800" /><br /><br/><br /><br/><span style="color: rgb(255, 0, 0);"><strong>Step 3:</strong></span> Click on product images to view details &gt; click<strong> Add to Basket</strong> to store product in your online shopping cart/basket &gt; and then click on <strong>Shopping Cart</strong> to view total product and price details. (কোনো প্রোডাক্ট এর বিবরণ জানতে হলে প্রোডাক্ট এর catagory হতে উক্ত প্রোডাক্ট আইটেমটির ছবির উপর ক্লিক করুন &gt; অতঃপর প্রোডাক্ট আইটেমটি পছন্দ হলে তা Shopping Cart এ যোগ করুন, Shopping Cart এ প্রোডাক্টটি add করার জন্য Add to Basket এ ক্লিক করুন &gt; তারপর, উক্ত নির্বাচিত প্রোডাক্টটির বিবরণ ও মূল্য জানার জন্য Shopping Cart icon টিতে ক্লিক করুন)<br /><br/><img src="<?= base_url('assets/front/');?>images/uploads/Banners/3.jpg" alt="3" align="absMiddle" height="461" border="1" width="723" /><br /><br/><span style="color: rgb(255, 0, 0);">

				<strong>Step 4:</strong></span> Click on <strong>Checkout</strong>. We offer discount codes on the homepage, on our Facebook page and via email during popular gift occasions such as Eid. You can use discount code and click &lsquo;Apply Discount&rsquo; on this page. Please apply discount code first and then click &lsquo;Checkout&rsquo;. (আমাদের Website এর homepage&nbsp; এ আমরা একটি monthly ডিসকাউন্ট কোড দিয়ে থাকি, এছাড়াও আমাদের ফেইসবুক পেজ এ ও e-mail&nbsp; এর মাধ্যমে বিভিন্ন জনপ্রিয় উৎসব যেমন ঈদ festivel এ ডিসকাউন্ট কোড sent করে থাকি. আপনি যদি ডিসকাউন্ট কোড পেতে আগ্রহী হন তবে Checkout বাটনটিতে&nbsp; ক্লিক করার পূর্বে উক্ত পেজএ&nbsp; Checkout বাটনটির নিচে Enter&nbsp; code&nbsp; box এ কোড টি লিখে &quot;Apply Discount&quot; এ ক্লিক করুন. অতঃপর, আপনি Checkout বাটনটি ক্লিক করবেন Note : অনুগ্রহ করে প্রথমে ডিসকাউন্ট কোডটি Apply করে, অন্তিমে আপনি checkout Button&nbsp; এ ক্লিক করবেন নয়তো ডিসকাউন্টটি&nbsp; আপনার পেমেন্ট এর সাথে ADD হবে না.)<br /><br/><img src="<?= base_url('assets/front/');?>images/uploads/Banners/4.jpg" alt="4" align="absMiddle" height="661" border="1" width="796" /><br /><br/><br /><br/><span style="color: rgb(255, 0, 0);">

				<strong>Step 5:</strong></span><strong> </strong>If you are a new customer, please click on <strong>Continue to Checkout</strong> button to register with your details. If you already have an account in our website, please type your email address and password in the left side of this page to login. (যদি আপনি আমাদের নতুন cutomer হয়ে থাকেন তবে অনুগ্রহ করে Continue to Checkout এ ক্লিক করুন এবং আমাদের ওয়েবসাইট&nbsp; আপনার পার্সোনাল তথ্য প্রদান করে নিউ কাস্টমার হিসেবে রেজিস্টার করুন. আর যদি আপনি আমারে website&nbsp; এ পূর্বে&nbsp; রেস্টাজিস্টের করে থাকেন তবে বাম পার্শে&nbsp; আপনার email&nbsp; address এবং password লিখে Login এ ক্লিক করুন.)<br /><br/><img src="<?= base_url('assets/front/');?>images/uploads/Banners/5.jpg" alt="5" align="absMiddle" height="522" border="1" width="800" /><br /><br/><br /><br/><span style="color: rgb(255, 0, 0);">

				<strong>Step 6: </strong></span>On the new customer registration page (Your invoice information), you must fill up the blank, which are star marked &gt; you have to accept and <strong>tick</strong> Terms & Condition. To proceed, click on Submit and Continue. (শুধুমাত্র নতুন কাস্টমার এর দৃষ্টি আকর্ষণ করে এ ধাপটি বিবরণ করা হয়েছে. নতুন কাস্টমারকে রেজিস্ট্রেশন পেজএ খালি জায়গাগুলো পূরণ করতে হবে. বিশেষ করে যেসব খালি জায়গাগুলো তে ষ্টার চিহ্ন রয়েছে অবশ্যই সেগুলো পূরণ করতে হবে. অতঃপর, আপনাকে&nbsp; রেজিস্ট্রেশন পেজটির নিচে &quot;Trems and&nbsp; condition&quot; -এ টিক দেয়ার পর &quot;Submit&nbsp; and&nbsp; Continue &quot; বাটন এ ক্লিক করতে হবে.)<br /><br/><img src="<?= base_url('assets/front/');?>images/uploads/Banners/6.jpg" alt="6" align="absMiddle" height="539" border="1" width="729" /><br /><br/><span style="color: rgb(255, 0, 0);">

				<strong>Step 7:</strong> </span>After registration/login, you will have to provide valid address for gift delivery. You will also have the option to select delivery date and time. (নিবন্ধন অথবা লগইন করার পরে, আপনার উপহারটি ডেলিভারি করার জন্য আপনাকে আপনার উপহার গ্রহণকারীর বৈধ ঠিকানা প্রদান করতে হবে এবং আপনাকে অবশই আপনার ডেলিভারির তারিখ ও সময় নির্বাচন করতে হবে।)<br /><br/><img src="<?= base_url('assets/front/');?>images/uploads/Banners/7.jpg" alt="7" align="absMiddle" height="501" border="1" width="713" /><br /><br/><span style="color: rgb(255, 0, 0);">


				<strong>Step 8:</strong></span><strong> </strong>Click <strong>Place Order Now</strong> to submit your order (অতঃপর, আপনার অর্ডারটি আমাদের system এ submit করার জন্য&nbsp; &quot;Place order now&quot; বাটনটি ক্লিক করবেন.)<br /><br/><img src="<?= base_url('assets/front/');?>images/uploads/Banners/4.jpg" alt="9" align="absMiddle" height="428" border="1" width="800" /><br /><br/><span style="color: rgb(255, 0, 0);"><strong>Step 10: </strong></span>Choose your preferable method and click on <strong>Make Payment </strong>(সর্বশেষে আপনার পছন্দ মতো payment method option টি সিলেক্ট করে Make Payment এ ক্লিক করুন)<br /><br/><img src="<?= base_url('assets/front/');?>images/uploads/Banners/10.jpg" alt="10" align="absMiddle" height="596" border="1" width="783" /><br /><br/><br />
				
			</div>
			<div class="clear"></div>
		</div>
	</div>
</div>
