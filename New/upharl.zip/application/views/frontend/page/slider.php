<div class="container">
	<div class="row">
		<div class="col-md-12 topmargin ">    
			<div class="main_banner_left_top">
				<a href="<?= base_url('welcome/Catelog');?>" alt="" style="display:block;width:100%;height:100%;">
					<img  src="<?= base_url('assets/front/');?>images/flower_delivery.png" alt="" />
					<h2>Free with every delivery</h2>
					<p>Seven red roses<br>
						Gift wrapping<br>
						Card & Candle<br>
						Photo confirmation
					</p>                            
				</a>
			</div>
			
			<div class="main_banner_mid_top">
				<a href="#" alt="">
					<img  src="<?= base_url('assets/front/');?>Slideshow/cake_delivery.png" alt="" />
				</a>
				<a href="<?= base_url('welcome/Catelog');?>" alt="">
					<img  src="<?= base_url('assets/front/');?>Slideshow/free_delivery.png" alt="" />
				</a>
				<a href="#" alt="">
					<img  src="<?= base_url('assets/front/');?>Slideshow/discount_code.png" alt="" />
				</a>
				<a href="#" alt="">
					<img  src="<?= base_url('assets/front/');?>Slideshow/same_day_gift_delivery.png" alt="" />
				</a>
			</div>
		

			<div style="cursor:pointer;" class="main_banner_right_top">
				<a href="#">
					<!-- <div class="ribbon"><span>12% Off</span></div> -->
					<h1>Flowers and Cake</h1>
					<h2>for any occupation surprise your loved ones.</h2>
				</a>
				<!-- <a class="main_banner_btn banner_button_dailyad" role="button" href="#">View Gifts</a> -->
			</div>
			
		    <div class="main_banner_left_bottom">
				<a href="saleitems/cat_saleItems.html" alt="" >
					<img  src="<?= base_url('assets/front/');?>images/gift_bangladesh.png" alt="" />
					<h1>5%-12% Off</h1>
					<h2>Sale Items</h2>
				</a>
				<!-- <a href="#" id="refl"  class="main_banner_btn banner_button_pink" role="button">Order Now</a> -->
			</div>

			<div style="cursor:pointer;" class="main_banner_mid_bottom_left">
				<img  src="<?= base_url('assets/front/');?>images/birthday_gift.png" alt="" />
				<h2>Gift delivery in<br> Sylhet</h2>           
			</div>
		

			<div style="cursor:pointer;" class="main_banner_mid_botr">
				<img  src="<?= base_url('assets/front/');?>images/gift_shop.png" alt="" />
				<h2>Gift delivery in Chittagong</h2>           
			</div>
		 

			<div style="cursor:pointer;" class="main_banner_right_bot">
				<a href="#">
					<h2>উপহারবাংলা.কম</h2>
					<h2>প্রিয়জনদের কাছে <br> উপহার পাঠান</h2>
				</a>
				<!-- <a class="main_banner_btn banner_button_red" role="button" href="#">About Us</a>
 -->			<a href="#"><img  src="<?= base_url('assets/front/images/online_shopping.png');?>" alt="" ></a>      
			</div>
		</div>
	</div>
</div>