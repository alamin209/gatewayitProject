<div id="mobile_categories_menu" style="display:none;padding:10px;width:80%;position:absolute;top:54px;left:0;z-index:9990;background-color:#fff;">
	<div class="leftmenu">

		<script type="text/javascript">
		<!--
		function initialiseMenu() { return false; }
		cF = new Image(); cF.src = "<?= base_url('assets/front/');?>images/arrowDown.png";
		cFO = new Image(); cFO.src = "<?= base_url('assets/front/');?>images/arrowActive.png";

		document.write ("<style>\n.cp { cursor: pointer; }\n<\/style>");
		-->
		</script>

		<ul id="Categories">

			<li><a href="same-day-and-urgent-gifts.html" style="background: url(images/uploads/icons/sameday_gift.png) no-repeat 8px 10px;">Same Day and Urgent Gifts</a></li>

			<li><a href="gift-packages-for-bd.html" style="background: url(images/uploads/icons/gift_combo.png) no-repeat 8px 10px;">Gift Packages for BD</a></li>

			<li><a href="fresh-flower-and-roses.html" style="background: url(images/uploads/icons/freshflower.png) no-repeat 8px 10px;">Fresh Flower and Roses</a></li>

			<li><a href="chittagong-city-free-gift-delivery.html" style="background: url(images/uploads/icons/chittagong_gift.png) no-repeat 8px 10px;">Chittagong City - Free Gift Delivery</a>
				<ul id="u208" style="display: none;">

					<li><a href="chittagong-city-free-gift-delivery/same-day-urgent-gift.html" style="background: url(images/uploads/icons/sameday_gift.png) no-repeat 8px 10px;">Same Day Urgent Gift</a></li>

					<li><a href="chittagong-city-free-gift-delivery/fresh-flowers.html" style="background: url(images/uploads/icons/freshflower.png) no-repeat 8px 10px;">Fresh Flowers</a></li>

					<li><a href="chittagong-city-free-gift-delivery/gift-packages.html" style="background: url(images/uploads/icons/gift_combo.png) no-repeat 8px 10px;">Gift Packages</a></li>

					<li><a href="chittagong-city-free-gift-delivery/sweets-and-pitha.html" style="background: url(images/uploads/icons/cakegift.png) no-repeat 8px 10px;">Sweets and Pitha</a></li>

					<li><a href="chittagong-city-free-gift-delivery/fruit-and-groceries.html" style="background: url(images/uploads/icons/groceries.png) no-repeat 8px 10px;">Fruit and Groceries</a></li>

					<li><a href="chittagong-city-free-gift-delivery/well-food-cakes.html" style="background: url(images/uploads/icons/cake-new.png) no-repeat 8px 10px;">Well food cakes</a></li>

					<li><a href="chittagong-city-free-gift-delivery/coopers-cake.html" style="background: url(images/uploads/icons/cake-new.png) no-repeat 8px 10px;">Coopers cake</a></li>

					<li><a href="chittagong-city-free-gift-delivery/cakes-from-hotcake.html" style="background: url(images/uploads/icons/cake-new.png) no-repeat 8px 10px;">Cakes from Hotcake</a></li>

					<li><a href="chittagong-city-free-gift-delivery/cake-from-kings-chittagong.html" style="background: url(images/uploads/icons/cake-new.png) no-repeat 8px 10px;">Cake from Kings Chittagong</a></li>

					<li><a href="chittagong-city-free-gift-delivery/food-delivery.html" style="background: url(images/uploads/icons/food_delivery.png) no-repeat 8px 10px;">Food Delivery</a></li>

					<li><a href="chittagong-city-free-gift-delivery/pizza-hut-home-delivery.html" style="background: url(images/uploads/icons/sameday_gift.png) no-repeat 8px 10px;">Pizza Hut home delivery</a></li>

					<li><a href="chittagong-city-free-gift-delivery/chocolate-and-ice-cream.html" style="background: url(images/uploads/icons/chocolate_gift.png) no-repeat 8px 10px;">Chocolate and Ice Cream</a></li>

					<li><a href="chittagong-city-free-gift-delivery/gift-for-kids.html" style="background: url(images/uploads/icons/kid.png) no-repeat 8px 10px;">Gift for Kids</a></li>

					<li><a href="chittagong-city-free-gift-delivery/teddy-bear-and-toys.html" style="background: url(images/uploads/icons/teddy.png) no-repeat 8px 10px;">Teddy bear and Toys</a></li>

					<li><a href="<?= base_url('welcome/GiftForHim/');?>" style="background: url(images/uploads/icons/man_dress.png) no-repeat 8px 10px;">Gift for Him</a></li>

					<li><a href="chittagong-city-free-gift-delivery/gift-for-her.html" style="background: url(images/uploads/icons/woman_dress.png) no-repeat 8px 10px;">Gift for Her</a></li>

					<li><a href="chittagong-city-free-gift-delivery/sharee-for-her.html" style="background: url(images/uploads/icons/dress.png) no-repeat 8px 10px;">Sharee for her</a></li>

					<li><a href="chittagong-city-free-gift-delivery/salwar-kamiz.html" style="background: url(images/uploads/icons/dress.png) no-repeat 8px 10px;">Salwar kamiz</a></li>

					<li><a href="chittagong-city-free-gift-delivery/unilever-gift-hampers.html" style="background: url(images/uploads/icons/unilever-gift.png) no-repeat 8px 10px;">Unilever Gift Hampers</a></li>

					<li><a href="chittagong-city-free-gift-delivery/household-appliances.html" style="background: url(images/uploads/icons/household.png) no-repeat 8px 10px;">Household Appliances</a></li>

					<li><a href="chittagong-city-free-gift-delivery/gift-for-newborn-and-baby.html" style="background: url(images/uploads/icons/new-born.png) no-repeat 8px 10px;">Gift for Newborn and Baby</a></li>

					<li><a href="chittagong-city-free-gift-delivery/recharge-mobile-phone.html" style="background: url(images/uploads/icons/mobile-recharge.png) no-repeat 8px 10px;">Recharge Mobile Phone</a></li>

					<li><a href="chittagong-city-free-gift-delivery/valentine-gift-packages.html" style="background: url(images/uploads/icons/wedding.png) no-repeat 8px 10px;">Valentine Gift Packages</a></li>

					<li><a href="chittagong-city-free-gift-delivery/pohela-boishakh-gifts.html" style="background: url(images/uploads/icons/boishak.png) no-repeat 8px 10px;">Pohela Boishakh Gifts</a></li>

					<li><a href="chittagong-city-free-gift-delivery/mothers-day-gift.html" style="background: url(images/uploads/icons/mothersday.png) no-repeat 8px 10px;">Mothers Day Gift</a></li>

					<li><a href="chittagong-city-free-gift-delivery/ramadan-and-iftar-gifts.html" style="background: url(images/uploads/icons/iftar.png) no-repeat 8px 10px;">Ramadan and Iftar Gifts</a></li>
				</ul>
			</li>


			<li><a href="cake-from-well-food.html" style="background: url(images/uploads/icons/cake-new.png) no-repeat 8px 10px;">Cake from Well Food</a></li>

			<li><a href="cakes-from-mr-baker.html" style="background: url(images/uploads/icons/cake-new.png) no-repeat 8px 10px;">Cakes from Mr. Baker</a></li>

			<li><a href="shumis-hot-cake.html" style="background: url(images/uploads/icons/cake-new.png) no-repeat 8px 10px;">Shumis Hot Cake</a></li>

			<li><a href="nutrient-cakes.html" style="background: url(images/uploads/icons/cake-new.png) no-repeat 8px 10px;">Nutrient Cakes</a></li>

			<li><a href="bread-and-beyond-cakes.html" style="background: url(images/uploads/icons/cake-new.png) no-repeat 8px 10px;">Bread and Beyond Cakes</a></li>

			<li><a href="special-cake-and-pastry.html" style="background: url(images/uploads/icons/cakegift.png) no-repeat 8px 10px;">Special Cake and Pastry</a></li>


			<li><a href="online-mobile-recharge.html" style="background: url(images/uploads/icons/mobile-recharge.png) no-repeat 8px 10px;">Online Mobile Recharge</a></li>

			<li><a href="food-court.html" style="background: url(images/uploads/icons/food_delivery.png) no-repeat 8px 10px;">Food Court</a>
				<ul id="u13" style="display: none;">

					<li><a href="food-court/biryani-and-deshi-food.html" style="background: url(images/uploads/icons/index.html) no-repeat 8px 10px;">Biryani and Deshi Food</a></li>

					<li><a href="food-court/kebab-burger-snacks.html" style="background: url(images/uploads/icons/index.html) no-repeat 8px 10px;">Kebab - Burger - Snacks</a></li>

					<li><a href="food-court/bangladeshi-pitha.html" style="background: url(images/uploads/icons/index.html) no-repeat 8px 10px;">Bangladeshi Pitha</a></li>

					<li><a href="food-court/chinese-and-thai-food.html" style="background: url(images/uploads/icons/index.html) no-repeat 8px 10px;">Chinese and Thai Food</a></li>

					<li><a href="food-court/pizza-hut-deals.html" style="background: url(images/uploads/icons/index.html) no-repeat 8px 10px;">Pizza Hut Deals</a></li>

					<li><a href="food-court/bfc-fast-food.html" style="background: url(images/uploads/icons/index.html) no-repeat 8px 10px;">BFC Fast Food</a></li>

					<li><a href="food-court/kfc-meal-deals.html" style="background: url(images/uploads/icons/index.html) no-repeat 8px 10px;">KFC Meal Deals</a></li>

					<li><a href="food-court/nandos-chicken.html" style="background: url(images/uploads/icons/index.html) no-repeat 8px 10px;">Nandos chicken</a></li>

					<li><a href="food-court/diabetic-food-items.html" style="background: url(images/uploads/icons/index.html) no-repeat 8px 10px;">Diabetic food items</a></li>

					<li><a href="food-court/chocolate-and-ice-cream.html" style="background: url(images/uploads/icons/index.html) no-repeat 8px 10px;">Chocolate and Ice Cream</a></li>

					<li><a href="food-court/paan-supari-packages.html" style="background: url(images/uploads/icons/index.html) no-repeat 8px 10px;">Paan Supari Packages</a></li>

					<li><a href="food-court/iftar-items.html" style="background: url(images/uploads/icons/index.html) no-repeat 8px 10px;">Iftar Items</a></li>
				</ul>
			</li>

			<li><a href="fresh-fruits-and-juices.html" style="background: url(images/uploads/icons/fresh-fruits.png) no-repeat 8px 10px;">Fresh Fruits and Juices</a></li>

			<li><a href="personalised-gifts.html" style="background: url(images/uploads/icons/new-born.png) no-repeat 8px 10px;">Personalised Gifts</a></li>

			<li><a href="aquarium-plant-pet-hobby-gifts.html" style="background: url(images/uploads/icons/greetings-cards.png) no-repeat 8px 10px;">Aquarium, Plant, Pet, Hobby Gifts</a></li>

			<li><a href="wedding-gifts-in-bangladesh.html" style="background: url(images/uploads/icons/valentines.png) no-repeat 8px 10px;">Wedding Gifts in Bangladesh</a></li>

			<li><a href="unilever-gift-hampers.html" style="background: url(images/uploads/icons/unilever-gift.png) no-repeat 8px 10px;">Unilever Gift Hampers</a></li>

			<li><a href="medical-and-healthcare.html" style="background: url(images/uploads/icons/medicine.png) no-repeat 8px 10px;">Medical and Healthcare</a></li>

			<li><a href="gifts-for-puja-and-holi.html" style="background: url(images/uploads/icons/puja.png) no-repeat 8px 10px;">Gifts for Puja and Holi</a></li>

			<li><a href="new-year-and-christmas-gift.html" style="background: url(images/uploads/icons/newyear-christmas.png) no-repeat 8px 10px;">New Year and Christmas gift</a></li>

			<li><a href="valentines-day-gift-packages.html" style="background: url(images/uploads/icons/wedding.png) no-repeat 8px 10px;">Valentines Day Gift Packages</a></li>

			<li><a href="pohela-boishakh-gifts.html" style="background: url(images/uploads/icons/boishakhi.png) no-repeat 8px 10px;">Pohela Boishakh Gifts</a></li>

			<li><a href="mothers-day-gift.html" style="background: url(images/uploads/icons/mothersday.png) no-repeat 8px 10px;">Mothers Day Gift</a></li>

			<li><a href="fathers-day-gifts.html" style="background: url(images/uploads/icons/fathersday.png) no-repeat 8px 10px;">Fathers Day Gifts</a></li>

			<li><a href="ramadan-and-iftar-gifts.html" style="background: url(images/uploads/icons/iftar.png) no-repeat 8px 10px;">Ramadan and Iftar Gifts</a></li>

			<li><a href="friendship-day-gift.html" style="background: url(images/uploads/icons/new-born.png) no-repeat 8px 10px;">Friendship Day Gift</a></li>

			<li><a href="corporate-promotional-gifts.html" style="background: url(images/uploads/icons/corporate.png) no-repeat 8px 10px;">Corporate Promotional Gifts</a></li>

		</ul>
		<br clear="all" />

		<div style="padding-top:10px;text-align:center;">
			<select name="lang" class="dropDown" onchange="jumpMenu('parent',this,0)">
				<option value="" >Australian $ (AU)</option>
				<option value="" selected="selected">BD Taka (BDT)</option>
				<option value="" >British Pounds (GB)</option>
				<option value="" >Canadian $ (CA)</option>
				<option value="" >Euro € (EUR)</option>
				<option value="" >US Dollars (US$)</option>
			</select>
		</div>
		<br clear="all"/>
	</div>
	<br clear="all"/>
</div>