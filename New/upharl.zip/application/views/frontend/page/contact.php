<div class="container">
	<div class="row">
		<div class="col-md-12">
			<div class="topnavarea">
				<a href="<?= base_url('welcome/');?>" title="HomePage">Home</a> /&nbsp;Contact Us
			</div>
		</div>
	</div>
</div>

<div class="container">
	<div class="row">
		<div class="col-md-12">
			<div class="leftmenuarea menudisplay">
				<div class="leftmenu">
					<?php include('leftmenu.php');?>
				</div>
			</div>
			<div class="rightcontentarea">
				<script type="text/javascript" src="https://www.upoharbd.com/swfobject.js"></script>
				<div class="headarea">
					<div class="headtext">Contact Us</div>
					<div class="share">
						<div style="margin-right:80px;float:right;width:80px">
							<!-- <iframe src="//www.facebook.com/plugins/like.php?href=http%3A%2F%2Fwww.upoharbd.com&width=152px&layout=button_count&action=like&show_faces=false&share=true&height=21&appId=182132298657766" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:152px; height:21px;" allowTransparency="true"></iframe> -->
						</div>
						<div style="float:left;"></div>
						<br clear="all"/>
					</div>
				</div>

				<!--Begin Comm100 Live Chat Code-->
				<!--<div id="comm100-button-5000000"></div>
				<script type="text/javascript">
					var Comm100API = Comm100API || new Object;
					Comm100API.chat_buttons = Comm100API.chat_buttons || [];
					var comm100_chatButton = new Object;
					comm100_chatButton.code_plan = 5000000;
					comm100_chatButton.div_id = 'comm100-button-5000000';
					Comm100API.chat_buttons.push(comm100_chatButton);
					Comm100API.site_id = 117055;
					Comm100API.main_code_plan = 5000000;
					var comm100_lc = document.createElement('script');
					comm100_lc.type = 'text/javascript';
					comm100_lc.async = true;
					comm100_lc.src = 'https://chatserver.comm100.com/livechat.ashx?siteId=' + Comm100API.site_id;
					var comm100_s = document.getElementsByTagName('script')[0];
					comm100_s.parentNode.insertBefore(comm100_lc, comm100_s);
				</script>-->
				<!--End Comm100 Live Chat Code-->
			
				<div class="ordertitle">Call Us</div>
				<div class="customerdetails">
					<strong>Bangladesh:</strong> +8801736981818,+8801947718662 <br />
					<strong>Newzealand:</strong> +64210375267 <br />
					<strong>UAE:</strong> +971556380805<br />
					<strong>Singapore:</strong> +6582082696 <br />
					<strong>Whatsapp, imo:</strong> +8801736981818:<br />
					<strong>Skype ID:</strong>
					<strong>306/1,Lalbagh (Beside Lalbagh Kellah) Dhaka -1211,Banglades</strong>
				</div>
				<div class="greetingtext">
					<p> More peoples of our customers in the world and every people send online
					gifts to their friends and families living in Bangladesh.We gift
					delivery from 6 am to 10 pm in Bangladesh.Upoharbangla open 365 days in
					a year.</p>
					<p><u>Order tracking & changes:</u> Please reply to the email that you have received as order / tracking confirmation. One of our staff will reply as soon as possible.</p>
				</div>

				<div class="ordertitle">Email Us</div>

				<div class="greetingtext">
					Please contact us if you can't find required information regarding gift to Bangladesh. We can also assist you with a gift item which is not available on our site or you were unable to find it Please submit an enquiry and we will get back to you as soon as possible.
				</div>

				<form action="" method="post" name="inquiry">
					<div class="contactbl">
						<table width="100%" border="0" cellspacing="5" cellpadding="5">
							<tr>
								<td height="30" colspan="2" align="left"><em>* required field</em></td>
							</tr>
							<tr>
								<td height="30" align="left">Full Name:  <span>*</span></td>
								<td height="30"><input type="text" name="name" value="" class="form-control"></td>
							</tr>
							<tr><td><p></p></td></tr>
							<tr>
								<td height="30" align="left">Email Address:  <span>*</span></td>
								<td height="30"><input type="text" name="email" value="" class="form-control"></td>
							</tr>
							<tr><td><p></p></td></tr>
							<tr>
								<td height="30" align="left">Phone:  <span>*</span></td>
								<td height="30"><input type="number" name="phone" value="" class="form-control"></td>
							</tr>
							<tr><td><p></p></td></tr>
							<tr>
								<td height="30" align="left" valign="top" style="padding:10px 0 0 0;">Your Message:  <span>*</span></td>
								<td height="30"><textarea name="enquiry" class="form-control" id="textfield5"></textarea></td>
							</tr>
							<tr><td><p></p></td></tr>
							<tr>
								<td height="30" align="left">Country:</td>
								<td height="30">
									<select name="country" id="country" class="form-control">
                                        <option value="">Select Country</option>
                                        <?php getAllCountryList(); ?>
                                    </select>
								</td>
							</tr>
							
							<tr>
								<td height="30" align="left"></td>
								<td height="30"><a href="javascript:submitDoc('inquiry');" class="sendbtn">Submit your query</a></td>
							</tr>
							<tr>
								<td height="30" align="left">&nbsp;</td>
								<td height="30">&nbsp;</td>
							</tr>
						</table>
					</div>
					<div class="clear"></div>
				</form>

				<!-- <h3>Offices in Bangladesh:</h3><p><br /></p>
				<iframe width="100%" height="320" frameborder="0" allowfullscreen="" style="border:0" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2582.174097292165!2d90.37329576619945!3d23.756448684510044!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755bf5364d6686d%3A0xcb947d8faf8aab90!2sUpoharbd.com!5e0!3m2!1sen!2sbd!4v1441354760765"></iframe> -->
				<br><br>
			
			</div>
		<div class="clear"></div>
		</div>
	</div> 
</div>