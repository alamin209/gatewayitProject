<div class="footerlinkarea">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<div class="col-lg-2">
					<div class="footerlistmenu">
						<ul>
							<li><a href="#">Alphabet and Number Cakes</a></li>
							<li><a href="#">Aquarium, Plant, Pet, Hobby Gifts</a></li>
							<li><a href="#">Bangladeshi Pitha</a></li>
							<li><a href="#"BFC Fast Food</a></li>
						</ul>
					</div>
				</div>
		  
				<div class="col-lg-2">
					<div class="footerlistmenu">
						<ul>
							<li><a href="#">Chocolate and Ice Cream</a></li>
							<li><a href="#">Chocolate, Ice Cream &amp; Cookies</a></li>
							<li><a href="#">Chocolate, Ice Cream &amp; Cookies</a></li>
							<li><a href="#">Coopers cake</a></li>
						</ul>
					</div>
				</div>
		  
				<div class="col-lg-2">
					<div class="footerlistmenu">
						<ul>
							<li><a href="#">Gift for Him</a></li>
							<li><a href="#">Gift for Him</a></li>
							<li><a href="#">Gift for Kids</a></li>
							<li><a href="#">Gift for Newborn and Baby</a></li>
						</ul>
					</div>
				</div>
		  
				<div class="col-lg-2">
					<div class="footerlistmenu">
						<ul>
							<li><a href="#">KFC Meal Deals</a></li>
							<li><a href="#">Kids Birthday Package</a></li>
							<li><a href="#">Kids Learning Materials</a></li>
							<li><a href="#">Kings Confectionery</a></li>
						</ul>
					</div>
				</div>
		  
				<div class="col-lg-2">
					<div class="footerlistmenu">
						<ul>
							<li><a href="#">Paan Supari Packages</a></li>
							<li><a href="#">Panjabi and Fotua</a></li>
							<li><a href="#">Perfume and Accessories</a></li>
							<li><a href="#">Perfume and Fashion for her</a></li>
						</ul>
					</div>
				</div>
		  
				<div class="col-lg-2">
					<div class="footerlistmenu">
						<ul>
							<li><a href="#">Saree for her</a></li>
							<li><a href="#">Sharee for her</a></li>
							<li><a href="#">Shirt and Pants</a></li>
							<li><a href="#">Shumis Hot Cake</a></li>
						</ul>
					</div>
				</div>
		  
			</div>
		</div>
	</div>
</div>