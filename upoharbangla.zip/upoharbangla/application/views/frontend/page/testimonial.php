<div class="container">
	<a href="#">
		<div class="row">
			<div class="col-md-12">
				<div class="testimonialarea">
					<h1>What Our Customers Say About Us</h1>
					<div class="testimonialul">
						<ul>
							<li> 
								<img src="<?= base_url('assets/front/images/tm1.png');?>" style="vertical-align:top; margin:0 7px 110px 0; float:left;">
								Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras interdum dapibus sem, nec consectetur est ultrices ut. Sed ut lacinia lectus, eget vestibulum erat. Maecenas eu facilisis dolor. Cras lacinia lobortis enim, eget dapibus libero interdum ac. Mauris vestibulum ante vel nisi convallis lobortis. 
								<img src="<?= base_url('assets/front/images/tm2.png');?>"><br>
								<img src="<?= base_url('assets/front/images/testline.gif');?>" style="margin-top:15px; margin-bottom:7px;"> <br>
								<strong>xyz</strong><br>
							</li>
					
							<li> 
								<img src="<?= base_url('assets/front/images/tm1.png');?>" style="vertical-align:top; margin:0 7px 110px 0; float:left;">
								Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras interdum dapibus sem, nec consectetur est ultrices ut. Sed ut lacinia lectus, eget vestibulum erat. Maecenas eu facilisis dolor. Cras lacinia lobortis enim, eget dapibus libero interdum ac. Mauris vestibulum ante vel nisi convallis lobortis. 
								<img src="<?= base_url('assets/front/images/tm2.png');?>"><br>
								<img src="<?= base_url('assets/front/images/testline.gif');?>" style="margin-top:15px; margin-bottom:7px;"> <br>
								<strong>xyz</strong><br>
							</li>
					
							<li> 
								<img src="<?= base_url('assets/front/images/tm1.png');?>" style="vertical-align:top; margin:0 7px 110px 0; float:left;">
								Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras interdum dapibus sem, nec consectetur est ultrices ut. Sed ut lacinia lectus, eget vestibulum erat. Maecenas eu facilisis dolor. Cras lacinia lobortis enim, eget dapibus libero interdum ac. Mauris vestibulum ante vel nisi convallis lobortis. 
								<img src="<?= base_url('assets/front/images/tm2.png');?>"><br>
								<img src="<?= base_url('assets/front/images/testline.gif');?>" style="margin-top:15px; margin-bottom:7px;"> <br>
								<strong>xyz</strong><br>
							</li>
					
						</ul>
						
						<div class="clear"></div>

						<div class="sharetest">
							<div class="mobileshare">
								<div style="float:left;width:90px;">
								</div>
								<div style="float:left;" class="menudisplay"></div>
								<br clear="all"/>
							</div>
						</div>
						<b clear="all"/>
					</div>
				</div>
			</div>
		</div>
	</a>
</div>