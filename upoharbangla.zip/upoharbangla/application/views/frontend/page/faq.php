
<div class="container">
	<div class="row">
		<div class="col-md-12">
			<div class="topnavarea">
				<a href="<?= base_url('welcome/');?>" title="HomePage">Home</a> /&nbsp;Gift delivery question and answer
			</div>
		</div>
	</div>
</div>

<div class="container">
	<div class="row">
		<div class="col-md-12">
			<div class="leftmenuarea menudisplay">
				<div class="leftmenu">
					<?php include('leftmenu.php');?>
				</div>
			</div>
			<div class="rightcontentarea">
				<div class="headarea">
					<div class="headtext">Gift delivery question and answer</div>
				</div>

				<div style="text-align: justify;">
					This page has answers to question about  gift delivery in all over Bangladesh.If you  do not find the answer to your question then please contact us.
				</div>

				<br/><h3>1.Where do we gifts deliver?</h3>
				<p>We deliver gifts flowers,teddy,cakes,helthcare,groceries,men dress,women
				dress,toys,to all cities of Bangladesh.</p>

				<br/><h3>2.Who deliver gift in Bangladesh?</h3>
				<p>Our service are delivery man by our own trained and trusted .All of our
				staff carry company issued photo ID.We do not use courier service to
				delivery any gift in
				Bangladesh.</p>

				<br/><h3>3.When delivery charge are applicable?</h3>
				<p>Dhaka metro area are gift delivery free.All gifts items and flowers are
				supply from Dhaka. If the order is for other cities for deliveries to
				outside of Dhaka,delivery charge will be added during checkout.Single
				charge is applicable to an order and it does not  matter how many
				products you have in an order.Delivery charge for all district cities of
				Bangladesh.</p>
				<p align='center'>
					<label>
						<select>
							<option>Dhaka - Free Delivery</option>
							<option>Bagerhat - Tk ৳2044.00</option>
							<option>Bandarban - Tk ৳2336.00</option>
							<option>Barguna - Tk ৳2044.00</option>
							<option>Barisal - Tk ৳2044.00</option>
							<option>Barnmanbaria - Tk ৳876.00</option>
							<option>Bhola - Tk ৳2044.00</option>
							<option>Bogra - Tk ৳1387.00</option>
							<option>Chadpur - Tk ৳1095.00</option>
							<option>Chapai Nawabgonj - Tk ৳1460.00</option>
							<option>Chittagong - Tk ৳1752.00</option>
							<option>Chuadanga - Tk ৳1606.00</option>
							<option>Comilla - Tk ৳876.00</option>
							<option>Coxs Bazar - Tk ৳2336.00</option>
							<option>Dinajpur - Tk ৳2044.00</option>
							<option>Faridpur - Tk ৳1095.00</option>
							<option>Feni - Tk ৳1095.00</option>
							<option>Gaibandha - Tk ৳1460.00</option>
							<option>Gazipur / Tongi - Tk ৳1022.00</option>
							<option>Gopalganj - Tk ৳1460.00</option>
							<option>Habiganj - Tk ৳1460.00</option>
							<option>Jaipurhat - Tk ৳1460.00</option>
							<option>Jamalpur - Tk ৳1022.00</option>
							<option>Jessore - Tk ৳1752.00</option>
							<option>Jhalakathi - Tk ৳2044.00</option>
							<option>Jhinaidah - Tk ৳1460.00</option>
							<option>Khulna - Tk ৳1752.00</option>
							<option>Kishoreganj - Tk ৳1095.00</option>
							<option>Kurigram - Tk ৳1606.00</option>
							<option>Kushtia - Tk ৳1460.00</option>
							<option>Lakshmipur - Tk ৳1460.00</option>
							<option>Lalmonirhat - Tk ৳1752.00</option>
							<option>Madaripur - Tk ৳1022.00</option>
							<option>Magura - Tk ৳1460.00</option>
							<option>Manikganj / Savar - Tk ৳1095.00</option>
							<option>Meherpur - Tk ৳1460.00</option>
							<option>Moulavibazar - Tk ৳1460.00</option>
							<option>Munshiganj - Tk ৳876.00</option>
							<option>Mymensingh - Tk ৳876.00</option>
							<option>Naogaon - Tk ৳1460.00</option>
							<option>Narayanganj - Tk ৳1022.00</option>
							<option>Narsingdi - Tk ৳876.00</option>
							<option>Natore - Tk ৳1460.00</option>
							<option>Netrokona - Tk ৳1387.00</option>
							<option>Nilphamari - Tk ৳1460.00</option>
							<option>Noakhali - Tk ৳1752.00</option>
							<option>Norail - Tk ৳1460.00</option>
							<option>Pabna - Tk ৳1387.00</option>
							<option>Panchagarh - Tk ৳1606.00</option>
							<option>Patuakhali - Tk ৳2044.00</option>
							<option>Pirojpur - Tk ৳2044.00</option>
							<option>Rajbari - Tk ৳1022.00</option>
							<option>Rajshahi - Tk ৳1460.00</option>
							<option>Rangamati - Tk ৳2336.00</option>
							<option>Rangpur - Tk ৳1752.00</option>
							<option>Satkhira - Tk ৳2044.00</option>
							<option>Shariyatpur - Tk ৳1387.00</option>
							<option>Sherpur - Tk ৳1095.00</option>
							<option>Sirajgonj - Tk ৳1387.00</option>
							<option>Sunamganj - Tk ৳1387.00</option>
							<option>Sylhet - Tk ৳1752.00</option>
							<option>Tangail - Tk ৳876.00</option>
							<option>Thakurgaon - Tk ৳1606.00</option>
						</select>
					</label>
				</p>

				<br/><h3>4.When do we gift delivery?</h3>
				<p>
				UPOHARBANGLA deliver gift flowers,food item, cakes, sweets,dress,
				helthcare item in all cities of Bangladesh.From 6 am in the morning to
				10 pm at night.You will have the option to select your prefered gift
				delivery time at checkout.</p>

				<br/><h3>5.How to seclect delivery date and time?</h3>
				<p>
				You can choose your prefered delivery time during checkout.Gift elivery
				time is given in Bangladesh for bad weather and traffic jam due to
				delivery problems.Such as 8 am to before 11 am.Delivery times of some
				items are dependent on the opening times of suppliers such as pizza
				hut,kfc product are available after 11 am and 4 seasons are available
				after 4 pm.</p>

				<br/><h3>6. What about our siurprise gift in Bangladesh?</h3>
				
				<p>You will get the option to seclect YES and NO 'call before delivery' at
				checkout.If you seclect YES we will call the ricipient in your given
				phone number.We will call them know when gift delivery time is set.If
				you seclect NO we do not call the recipient.We will reach the address to
				surprise the recipient.At that time if we do not have this recipient,we
				will be giving gift to someone who is familiar with delivery address.</p>

				<br/><h3>7.How to add cake wish?</h3>
				<p>During checkout you will find the option to give it.</p>

				<br/><h3>8.What are the free items with every gift delivery?</h3>
				<p>Our main focus is on product quality and service.We offer a free red
				rose ,photo confirmation with a free greeting card of each order.At the
				time of checkout you will get the greeting card write option.Can be
				type.</p>

				<br/><h3>9.When you will send gift order?</h3>
				<p>As soon as your order it will be good for you.Before the gifts will be
				added to the schedul upon 36 ho

				As soon as you order it will be good for you.Before the gifts will be
				added to the schedul upon 36 hours before your call the delivery was
				requested.But we also know that its not always possible to order.So we
				have an urgent order and delivery option on the same day. You can order
				untile 4 pm on dhaka time.</p>

				<br/><h3>10.How to order gift online and not know what to do?</h3>
				<p>How to order in Bangladesh its video demo at our HELP PAGE.</p>

				<br/><h3>11.Can we gifts delivery without his/ her address?</h3>
				<p>Yes as you can come to our UPOHARBANGLA.COM [1] OFFICE AT
				LALBAGH,DHAKA-1211.Or at any public place like a shopping mall,travel
				spot or university,hospital, you  can call us to come.</p>
				<br/>

				<h3>12.How do we delivery strikes in Bangladesh or any bad situation?</h3>
				<p>We will contact you as soon as possible and find a suitable time for
				gift delivery in Bangladesh.</p>
				<br/>

				<h3>13.How do we send order payment and gift delivery confirmation?</h3>
				<p>
				# UPOHARBANGLA always keeps contact with customers.You will receive an
				E-MAIL as soon as you place yuor order.This E-MAIL will have an order
				number please check JUNK/SPAN folder and check with your INBOX.When your
				order adds to the gift delivery schedule.Then you will get a 4 DIGIT
				tracking number in your mail.

				# You can contact us with the tracking number.You can leran more about
				the order by LOGGIN in to your account.

				# If you pay on CREDIT CARD you will get a CONFIRMATION MESSAGE that you
				are in the processing status.If you make payment via OFFLINE METHOD such
				as BKASH,BANK DEPOSIT,WESTERN UNION you will receive an email with
				payment instruction.after payment cleared we will process your order.

				# You can ask question,change or order with a message in UPOHARBANGLA
				MAIL.

				# After gift delivery you will receive an email.You will get PHOTO
				CONFIRMATION within 24-36 hours of delivery.</p>
				<br/>

				<h3>14.What is photo confirmation?</h3>
				<p>Photo guarantee is a unique service of UPOHARBANGLA.Let me tell you what
				you gave.During checkout you can choose YES or NO. If seclect YES we
				will confirm the recipients photo.If seclect NO we will not confirm the
				recipients photo.A great way to see a free service and your friends and
				family members in Bangladesh.Keep an eye on our FACEBOOK PAGE to view
				pictures of recent gift packages.</p>
				<br/>

				<h3>15.What you don't know the recipient address?</h3>
				<p>Give us the delivery time date and recipint phone number.We will know
				HIS/HER address by calling.</p>

				<h3>16.What is the guarantee of reaching the right time order?</h3>
				<p>UPOHARBANGLA is the best gift delivery service in Bangladesh.Complete
				online gift shop,tracking process,gift delivery and customer service
				through the upgradable supplier and 5 years experience.You must be
				satisfied by seeing the gift of recipient gift.</p>

			</div>
			<div class="clear"></div>
		</div>
	</div>
</div>